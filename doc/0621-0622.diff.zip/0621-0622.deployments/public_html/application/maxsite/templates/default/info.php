<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

/**
 * MaxSite CMS
 * (c) http://max-3000.com/
 */

# в этом файле нужно указать основную информацию о шаблоне

$info = array(
	'name' => 'Default',
	'description' => t('Шаблон для MaxSite CMS', __FILE__),
	'version' => '2.9',
	'author' => 'Максим',
	'template_url' => 'http://max-3000.com/',
	'author_url' => 'http://maxsite.org/'
);

# end file