<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>

	<style> div.comments-link {display: none} div.info a {text-decoration: none}</style>	 
