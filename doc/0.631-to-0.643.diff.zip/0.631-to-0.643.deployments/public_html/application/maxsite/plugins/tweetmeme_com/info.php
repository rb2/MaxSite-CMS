<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

$info = array(
	'name' => t('Блок tweet me'),
	'description' => t('Выводит блок, в котором указывается количество поддержавших запись пользователей Twitter. Используется сервис <a href="http://tweetmeme.com/" target="_blank">tweetmeme.com</a> или оригинальный <a href="http://twitter.com/" target="_blank">twitter.com</a>'),
	'version' => '1.8',
	'author' => 'MAX',
	'plugin_url' => 'http://max-3000.com/',
	'author_url' => 'http://maxsite.org/',
	'group' => 'template'
);

# end file