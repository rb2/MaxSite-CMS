<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

$info = array(
	'name' => 'Forms',
	'description' => t('Формы для отправки на указанный email'),
	'version' => '1.7',
	'author' => 'Максим',
	'plugin_url' => 'http://max-3000.com/',
	'author_url' => 'http://maxsite.org/',
	'group' => 'template',
	'help' => getinfo('plugins_url') . 'forms/readme.txt',
);

# end file