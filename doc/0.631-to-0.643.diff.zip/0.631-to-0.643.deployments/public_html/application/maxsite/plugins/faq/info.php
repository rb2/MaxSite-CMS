<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

$info = array(
	'name' => 'FAQ',
	'description' => t('Плагин для организации FAQ на странице. Код:<br>[faqs] [faq=вопрос]ответ[/faq] [faq=вопрос2]ответ2[/faq] [/faqs]'),
	'version' => '1.2',
	'author' => 'MAX',
	'plugin_url' => 'http://max-3000.com/',
	'author_url' => 'http://maxsite.org/',
	'group' => 'template'
);

# end file