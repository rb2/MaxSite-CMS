<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 

	# дополнительный файл к functions.php
	
	// mso_register_sidebar('2', t('Второй сайдбар'));

