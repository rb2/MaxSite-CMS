<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); 
	
	echo '<div class="comments">';
	echo '<h3 class="comments">' . t('Комментариев') . ': ' . count($comments) . '</h3>';
		
